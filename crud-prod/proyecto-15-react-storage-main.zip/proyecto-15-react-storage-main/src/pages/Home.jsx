import styled from "styled-components";
export function Home() {
  return (<Container>
<h1>Home</h1>
  </Container>);
}
const Container =styled.div`
  
`