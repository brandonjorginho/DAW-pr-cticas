###### PANTALLAZO DEL PROYECTO
![](https://i.ibb.co/dLwp1ky/fgergfdgdfg.png)
![](https://i.ibb.co/ZfqjW1J/logica-proyecto-storage.png)
###### TUTORIAL PASO A PASO de éste y 14 proyectos más EN https://codigo369.com/
![](https://i.ibb.co/R3b4j0N/rfgwe4werwer-1.png)
